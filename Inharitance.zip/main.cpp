#include <iostream>
using namespace std;

// Базовый класс
class CAnimal
{
	protected:
		char *name;       // атрибут базового класса
	public:
		// Методы базового класса
		void SetName(char *pet_name);
		void Eats(void);
};

// Производный (дочерний) класс, наследующий от CAnimal
class CDog : public CAnimal
{
	public:
		char *color;  // атрибут класса CDog
		void Says();  // метод класса CDog
};

// Производный (дочерний) класс, наследующий от CAnimal
class CCat : public CAnimal
{
	public:
		char *color;  // атрибут класса CCat
		void Says();  // метод класса CCat
};

void CAnimal::SetName(char *pet_name)
{
	name = pet_name;
}

void CAnimal::Eats(void)   // Метод базового класса
{
	cout << name << " eats.\n";
}

void CDog::Says(void)  // метод класса CDog
{
	cout << name << " says Gav-gav-gav!\n";
}

void CCat::Says(void)  // метод класса CCat
{
	cout << name << " meows... \n";
}

//------------------------------------------------------------------------
int main()
{
	CAnimal animal; // экземпляр какого-то животного
	//animal.name = "Pet"; // ОШИБКА
	animal.SetName("Pet");
	animal.Eats();

	CDog dog;  // экземпляр собаки
	dog.SetName("Gek");
	dog.Eats();
	dog.Says();

	CCat cat;  // экземпляр кота
	cat.SetName("Margo");
	cat.Eats();
	cat.Says();

	return 0;
}